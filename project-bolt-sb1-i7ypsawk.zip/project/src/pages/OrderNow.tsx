import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { Plus, Minus, Clock, CreditCard, Truck } from 'lucide-react';

const OrderNow = () => {
  const { state, dispatch } = useCart();
  const [email, setEmail] = useState('');
  const [emailSubmitted, setEmailSubmitted] = useState(false);

  const bowls = [
    { id: 'classic', name: 'Classic Bowl', price: 80, description: 'Seasonal fruits mix' },
    { id: 'protein', name: 'Protein Bowl', price: 120, description: 'High-protein with nuts' },
    { id: 'vitamin', name: 'Vitamin Bowl', price: 100, description: 'Vitamin-rich citrus & berries' },
    { id: 'weight-loss', name: 'Weight Loss Bowl', price: 110, description: 'Low-calorie, high-fiber' },
    { id: 'kids', name: "Kids' Bowl", price: 90, description: 'Kid-friendly shapes' },
    { id: 'exotic', name: 'Exotic Bowl', price: 150, description: 'Premium exotic fruits' }
  ];

  const extras = [
    { id: 'egg', name: 'Boiled Egg', price: 15 },
    { id: 'nuts', name: 'Mixed Nuts', price: 25 },
    { id: 'sprouts', name: 'Sprouts', price: 10 },
    { id: 'extra-fruits', name: 'Extra Fruits', price: 20 }
  ];

  const timeSlots = [
    { value: '7:00 AM – 9:00 AM', label: '7:00 AM – 9:00 AM', popular: true },
    { value: '12:00 PM – 2:00 PM', label: '12:00 PM – 2:00 PM', popular: false },
    { value: '5:00 PM – 7:00 PM', label: '5:00 PM – 7:00 PM', popular: false }
  ];

  const orderTypes = [
    { value: 'one-time', label: 'One-time Order', discount: 0 },
    { value: 'daily', label: 'Daily Subscription', discount: 10 },
    { value: 'weekly', label: 'Weekly Subscription', discount: 15 }
  ];

  const addItem = (item: any, type: 'bowl' | 'extra') => {
    dispatch({ type: 'ADD_ITEM', payload: { ...item, type } });
  };

  const removeItem = (id: string) => {
    dispatch({ type: 'REMOVE_ITEM', payload: id });
  };

  const updateQuantity = (id: string, quantity: number) => {
    dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantity } });
  };

  const getItemQuantity = (id: string) => {
    const item = state.items.find(item => item.id === id);
    return item ? item.quantity : 0;
  };

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email) {
      console.log('Email submitted for notifications:', email);
      setEmailSubmitted(true);
      setEmail('');
    }
  };

  const handlePlaceOrder = () => {
    if (state.items.length === 0) {
      alert('Please add items to your cart before placing an order.');
      return;
    }
    
    const orderData = {
      items: state.items,
      total: state.total,
      deliveryTime: state.deliveryTime,
      orderType: state.orderType,
      paymentMethod: state.paymentMethod,
      timestamp: new Date().toISOString()
    };
    
    console.log('Order placed:', orderData);
    alert('Order placed successfully! We will contact you for confirmation.');
    dispatch({ type: 'CLEAR_CART' });
  };

  return (
    <div className="min-h-screen py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Place Your Order</h1>
          <p className="text-xl text-gray-600">Customize your perfect fruit bowl experience</p>
        </div>

        {/* Trial Bowl Promotion */}
        <div className="bg-gradient-to-r from-orange-500 to-red-500 rounded-xl p-6 mb-12 text-white text-center">
          <h2 className="text-2xl font-bold mb-2">Try our ₹90 Trial Bowl</h2>
          <p className="mb-4">Perfect for first-time customers - get a taste of our quality!</p>
          <button
            onClick={() => addItem({ id: 'trial', name: 'Trial Bowl', price: 90 }, 'bowl')}
            className="bg-white text-orange-500 px-6 py-2 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
          >
            Order Trial Bowl
          </button>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Left Column - Selection */}
          <div className="lg:col-span-2 space-y-12">
            {/* Select Your Bowl */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Select Your Bowl</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {bowls.map((bowl) => (
                  <div
                    key={bowl.id}
                    className={`bg-white rounded-xl p-6 border-2 cursor-pointer transition-all ${
                      getItemQuantity(bowl.id) > 0
                        ? 'border-green-500 bg-green-50'
                        : 'border-gray-200 hover:border-green-300'
                    }`}
                    onClick={() => addItem(bowl, 'bowl')}
                  >
                    <div className="flex justify-between items-start mb-3">
                      <h3 className="text-lg font-bold text-gray-900">{bowl.name}</h3>
                      <span className="text-xl font-bold text-green-600">₹{bowl.price}</span>
                    </div>
                    <p className="text-gray-600 text-sm mb-4">{bowl.description}</p>
                    {getItemQuantity(bowl.id) > 0 && (
                      <div className="flex items-center justify-between bg-white rounded-lg p-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            updateQuantity(bowl.id, getItemQuantity(bowl.id) - 1);
                          }}
                          className="text-gray-500 hover:text-red-500"
                        >
                          <Minus className="w-4 h-4" />
                        </button>
                        <span className="font-semibold">{getItemQuantity(bowl.id)}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            updateQuantity(bowl.id, getItemQuantity(bowl.id) + 1);
                          }}
                          className="text-gray-500 hover:text-green-500"
                        >
                          <Plus className="w-4 h-4" />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </section>

            {/* Add Extras */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Add Extras</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                {extras.map((extra) => (
                  <div
                    key={extra.id}
                    className={`bg-white rounded-xl p-4 border-2 cursor-pointer transition-all text-center ${
                      getItemQuantity(extra.id) > 0
                        ? 'border-green-500 bg-green-50'
                        : 'border-gray-200 hover:border-green-300'
                    }`}
                    onClick={() => addItem(extra, 'extra')}
                  >
                    <h3 className="font-semibold text-gray-900 mb-1">{extra.name}</h3>
                    <span className="text-green-600 font-bold">₹{extra.price}</span>
                    {getItemQuantity(extra.id) > 0 && (
                      <div className="flex items-center justify-center space-x-2 mt-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            updateQuantity(extra.id, getItemQuantity(extra.id) - 1);
                          }}
                          className="text-gray-500 hover:text-red-500"
                        >
                          <Minus className="w-3 h-3" />
                        </button>
                        <span className="font-semibold text-sm">{getItemQuantity(extra.id)}</span>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            updateQuantity(extra.id, getItemQuantity(extra.id) + 1);
                          }}
                          className="text-gray-500 hover:text-green-500"
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </section>

            {/* Delivery Time */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
                <Clock className="w-6 h-6 mr-2" />
                Delivery Time
              </h2>
              <div className="space-y-3">
                {timeSlots.map((slot) => (
                  <label key={slot.value} className="flex items-center space-x-3 cursor-pointer">
                    <input
                      type="radio"
                      name="deliveryTime"
                      value={slot.value}
                      checked={state.deliveryTime === slot.value}
                      onChange={(e) => dispatch({ type: 'SET_DELIVERY_TIME', payload: e.target.value })}
                      className="text-green-500 focus:ring-green-500"
                    />
                    <span className="text-gray-900">{slot.label}</span>
                    {slot.popular && (
                      <span className="bg-orange-100 text-orange-600 text-xs px-2 py-1 rounded-full font-medium">
                        Popular
                      </span>
                    )}
                  </label>
                ))}
              </div>
            </section>

            {/* Order Type */}
            <section>
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Order Type</h2>
              <div className="space-y-3">
                {orderTypes.map((type) => (
                  <label key={type.value} className="flex items-center justify-between p-4 bg-white rounded-lg border-2 border-gray-200 cursor-pointer hover:border-green-300 transition-colors">
                    <div className="flex items-center space-x-3">
                      <input
                        type="radio"
                        name="orderType"
                        value={type.value}
                        checked={state.orderType === type.value}
                        onChange={(e) => dispatch({ type: 'SET_ORDER_TYPE', payload: e.target.value as any })}
                        className="text-green-500 focus:ring-green-500"
                      />
                      <span className="text-gray-900 font-medium">{type.label}</span>
                    </div>
                    {type.discount > 0 && (
                      <span className="bg-green-100 text-green-600 text-sm px-3 py-1 rounded-full font-medium">
                        Save {type.discount}%
                      </span>
                    )}
                  </label>
                ))}
              </div>
            </section>

            {/* Payments Coming Soon */}
            <section className="bg-blue-50 rounded-xl p-6">
              <h2 className="text-2xl font-bold text-gray-900 mb-4 flex items-center">
                <CreditCard className="w-6 h-6 mr-2" />
                Payments Coming Soon
              </h2>
              <p className="text-gray-600 mb-4">
                We're working on adding UPI, credit/debit cards, and net banking options. Get notified when they're ready!
              </p>
              {!emailSubmitted ? (
                <form onSubmit={handleEmailSubmit} className="flex flex-col sm:flex-row gap-3">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                  <button
                    type="submit"
                    className="px-6 py-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-colors font-medium"
                  >
                    Get Notified
                  </button>
                </form>
              ) : (
                <div className="text-green-600 font-medium">
                  ✓ Thank you! We'll notify you when online payments are available.
                </div>
              )}
            </section>
          </div>

          {/* Right Column - Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-xl shadow-lg p-6 sticky top-24">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Order Summary</h2>

              {state.items.length === 0 ? (
                <p className="text-gray-500 text-center py-8">Your cart is empty</p>
              ) : (
                <>
                  <div className="space-y-4 mb-6">
                    {state.items.map((item) => (
                      <div key={item.id} className="flex items-center justify-between">
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-900">{item.name}</h3>
                          <p className="text-sm text-gray-500">₹{item.price} × {item.quantity}</p>
                        </div>
                        <div className="flex items-center space-x-2">
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="text-gray-400 hover:text-red-500"
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-8 text-center font-medium">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="text-gray-400 hover:text-green-500"
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="border-t border-gray-200 pt-4 mb-6">
                    <div className="flex justify-between items-center text-xl font-bold">
                      <span>Total:</span>
                      <span className="text-green-600">₹{state.total}</span>
                    </div>
                    {state.orderType !== 'one-time' && (
                      <p className="text-sm text-green-600 mt-1">
                        {state.orderType === 'daily' ? '10%' : '15%'} subscription discount applied
                      </p>
                    )}
                  </div>

                  <div className="space-y-4 mb-6">
                    <div className="flex items-center space-x-3 text-sm text-gray-600">
                      <Truck className="w-4 h-4" />
                      <span>Delivery: {state.deliveryTime}</span>
                    </div>
                    <div className="flex items-center space-x-3 text-sm text-gray-600">
                      <CreditCard className="w-4 h-4" />
                      <span>Payment: Cash on Delivery</span>
                    </div>
                  </div>

                  <button
                    onClick={handlePlaceOrder}
                    className="w-full bg-green-500 text-white py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors"
                  >
                    Place Order
                  </button>

                  <p className="text-xs text-gray-500 mt-3 text-center">
                    By placing an order, you agree to our terms and conditions
                  </p>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderNow;