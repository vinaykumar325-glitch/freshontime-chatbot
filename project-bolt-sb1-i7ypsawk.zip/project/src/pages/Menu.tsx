import React from 'react';
import { Link } from 'react-router-dom';
import { Plus } from 'lucide-react';

const Menu = () => {
  const bowls = [
    {
      id: 'classic',
      name: 'Classic Bowl',
      price: 80,
      description: 'A perfect mix of seasonal fruits - apple, banana, orange, and grapes',
      image: 'https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=400',
      popular: false
    },
    {
      id: 'protein',
      name: 'Protein Bowl',
      price: 120,
      description: 'High-protein fruits with nuts and seeds - perfect for fitness enthusiasts',
      image: 'https://images.pexels.com/photos/1640774/pexels-photo-1640774.jpeg?auto=compress&cs=tinysrgb&w=400',
      popular: true
    },
    {
      id: 'vitamin',
      name: 'Vitamin Bowl',
      price: 100,
      description: 'Vitamin-rich citrus fruits and berries to boost your immunity',
      image: 'https://images.pexels.com/photos/1435735/pexels-photo-1435735.jpeg?auto=compress&cs=tinysrgb&w=400',
      popular: false
    },
    {
      id: 'weight-loss',
      name: 'Weight Loss Bowl',
      price: 110,
      description: 'Low-calorie, high-fiber fruits to support your weight management goals',
      image: 'https://images.pexels.com/photos/1120575/pexels-photo-1120575.jpeg?auto=compress&cs=tinysrgb&w=400',
      popular: false
    },
    {
      id: 'kids',
      name: "Kids' Bowl",
      price: 90,
      description: 'Kid-friendly fruits cut in fun shapes - apple, banana, and strawberries',
      image: 'https://images.pexels.com/photos/1128678/pexels-photo-1128678.jpeg?auto=compress&cs=tinysrgb&w=400',
      popular: false
    },
    {
      id: 'exotic',
      name: 'Exotic Bowl',
      price: 150,
      description: 'Premium exotic fruits - dragon fruit, kiwi, passion fruit, and mango',
      image: 'https://images.pexels.com/photos/1099680/pexels-photo-1099680.jpeg?auto=compress&cs=tinysrgb&w=400',
      popular: false
    }
  ];

  const extras = [
    { id: 'egg', name: 'Boiled Egg', price: 15 },
    { id: 'nuts', name: 'Mixed Nuts', price: 25 },
    { id: 'sprouts', name: 'Sprouts', price: 10 },
    { id: 'extra-fruits', name: 'Extra Fruits', price: 20 }
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Our Fresh Menu
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Choose from our carefully crafted fruit bowls, each designed to meet your specific health and taste preferences
          </p>
        </div>

        {/* Fruit Bowls */}
        <section className="mb-20">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Fruit Bowls</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {bowls.map((bowl) => (
              <div key={bowl.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                {bowl.popular && (
                  <div className="bg-orange-500 text-white text-sm font-semibold px-4 py-2 text-center">
                    Most Popular
                  </div>
                )}
                <img
                  src={bowl.image}
                  alt={bowl.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-6">
                  <div className="flex justify-between items-start mb-3">
                    <h3 className="text-xl font-bold text-gray-900">{bowl.name}</h3>
                    <span className="text-2xl font-bold text-green-600">₹{bowl.price}</span>
                  </div>
                  <p className="text-gray-600 text-sm leading-relaxed mb-4">
                    {bowl.description}
                  </p>
                  <Link
                    to="/order"
                    className="w-full bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 transition-colors flex items-center justify-center space-x-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add to Order</span>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Add-ons */}
        <section className="mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Add-ons</h2>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {extras.map((extra) => (
              <div key={extra.id} className="bg-white rounded-xl shadow-md p-6 text-center hover:shadow-lg transition-shadow">
                <h3 className="text-lg font-semibold text-gray-900 mb-2">{extra.name}</h3>
                <span className="text-xl font-bold text-green-600">₹{extra.price}</span>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <div className="text-center bg-gray-50 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to Order?
          </h2>
          <p className="text-xl text-gray-600 mb-8">
            Customize your perfect fruit bowl and get it delivered fresh to your doorstep
          </p>
          <Link
            to="/order"
            className="inline-flex items-center px-8 py-4 bg-orange-500 text-white font-semibold rounded-lg hover:bg-orange-600 transition-colors shadow-lg"
          >
            Start Your Order
            <Plus className="ml-2 w-5 h-5" />
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Menu;