import React from 'react';
import { Heart, Leaf, Clock, Users } from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: <Heart className="w-8 h-8" />,
      title: "Health First",
      description: "We believe in promoting healthy eating habits through fresh, nutritious fruit bowls that fuel your body and mind."
    },
    {
      icon: <Leaf className="w-8 h-8" />,
      title: "Fresh & Natural",
      description: "All our fruits are sourced directly from local farms, ensuring maximum freshness and natural goodness in every bowl."
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: "On-Time Delivery",
      description: "We respect your time and ensure that your fresh fruit bowls are delivered precisely when you need them."
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: "Community Focus",
      description: "We're committed to supporting local farmers and building a healthier community, one fruit bowl at a time."
    }
  ];

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Hero Section */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-6">About Fresh on Time</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            We're passionate about making healthy eating convenient and accessible for everyone. 
            Our mission is to deliver fresh, nutritious fruit bowls that fit perfectly into your daily routine.
          </p>
        </div>

        {/* Story Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center mb-20">
          <div className="space-y-6">
            <h2 className="text-3xl font-bold text-gray-900">Our Story</h2>
            <p className="text-gray-600 leading-relaxed">
              Fresh on Time was born from a simple observation: people want to eat healthy, 
              but busy lifestyles often get in the way. We realized that by delivering freshly 
              prepared fruit bowls at convenient times, we could help people maintain their 
              health goals without compromising their schedules.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Starting in 2024, we began with a small team dedicated to sourcing the freshest 
              fruits from local farms and creating delicious, nutritious combinations. Today, 
              we're proud to serve hundreds of health-conscious customers across the city.
            </p>
            <p className="text-gray-600 leading-relaxed">
              Every bowl we prepare is a testament to our commitment to quality, freshness, 
              and the belief that healthy eating should be convenient and enjoyable.
            </p>
          </div>
          <div className="relative">
            <img
              src="https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800"
              alt="Fresh fruits preparation"
              className="rounded-2xl shadow-xl w-full h-96 object-cover"
            />
          </div>
        </div>

        {/* Values Section */}
        <div className="mb-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Values</h2>
            <p className="text-xl text-gray-600">
              These core principles guide everything we do at Fresh on Time
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center space-y-4">
                <div className="inline-flex items-center justify-center w-16 h-16 bg-green-100 text-green-600 rounded-full">
                  {value.icon}
                </div>
                <h3 className="text-xl font-bold text-gray-900">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Team Section */}
        <div className="bg-gray-50 rounded-2xl p-12 mb-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Meet Our Team</h2>
            <p className="text-xl text-gray-600">
              The passionate people behind your fresh fruit bowls
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-green-400 to-green-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-white text-3xl font-bold">R</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Rahul Singh</h3>
              <p className="text-gray-600 mb-3">Founder & CEO</p>
              <p className="text-sm text-gray-500">
                Passionate about healthy living and making fresh fruits accessible to everyone.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-orange-400 to-orange-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-white text-3xl font-bold">P</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Priya Patel</h3>
              <p className="text-gray-600 mb-3">Head of Operations</p>
              <p className="text-sm text-gray-500">
                Ensures every fruit bowl meets our high standards of quality and freshness.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-32 h-32 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full mx-auto mb-4 flex items-center justify-center">
                <span className="text-white text-3xl font-bold">A</span>
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-2">Arjun Kumar</h3>
              <p className="text-gray-600 mb-3">Nutrition Expert</p>
              <p className="text-sm text-gray-500">
                Designs our fruit bowl combinations for maximum nutritional benefits.
              </p>
            </div>
          </div>
        </div>

        {/* Mission Statement */}
        <div className="text-center bg-gradient-to-br from-green-50 to-emerald-100 rounded-2xl p-12">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Mission</h2>
          <p className="text-xl text-gray-600 max-w-4xl mx-auto leading-relaxed">
            To make healthy eating effortless by delivering fresh, nutritious fruit bowls 
            that fit seamlessly into your lifestyle. We're committed to supporting your 
            wellness journey while promoting sustainable farming practices and building 
            stronger communities.
          </p>
        </div>
      </div>
    </div>
  );
};

export default About;