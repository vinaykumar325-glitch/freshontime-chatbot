import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Star, Clock, Truck } from 'lucide-react';

const Home = () => {
  const testimonials = [
    {
      name: "Priya Sharma",
      text: "Fresh on Time has transformed my mornings! The fruit bowls are always perfectly fresh and delivered right on time.",
      rating: 5
    },
    {
      name: "Rajesh Kumar",
      text: "Love the variety and quality. The protein bowl keeps me energized throughout the day.",
      rating: 5
    },
    {
      name: "Anita Patel",
      text: "My kids absolutely love their fruit bowls. Great way to ensure they get their daily nutrition.",
      rating: 5
    }
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-green-50 to-emerald-100 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <div className="space-y-4">
                <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
                  Your New Daily
                  <span className="text-green-600 block">Fruit Habit</span>
                </h1>
                <p className="text-xl text-gray-600 leading-relaxed">
                  Fresh fruit bowls delivered to your doorstep every day. Start your healthy journey with us!
                </p>
              </div>
              
              <Link
                to="/order"
                className="inline-flex items-center px-8 py-4 bg-orange-500 text-white font-semibold rounded-lg hover:bg-orange-600 transition-colors shadow-lg hover:shadow-xl group"
              >
                Order Now
                <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </Link>

              {/* Features */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-8">
                <div className="flex items-center space-x-3">
                  <Clock className="w-8 h-8 text-green-500" />
                  <span className="text-sm font-medium text-gray-700">On-time delivery</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Truck className="w-8 h-8 text-green-500" />
                  <span className="text-sm font-medium text-gray-700">Fresh daily</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Star className="w-8 h-8 text-green-500" />
                  <span className="text-sm font-medium text-gray-700">Premium quality</span>
                </div>
              </div>
            </div>

            <div className="relative">
              <img
                src="https://images.pexels.com/photos/1092730/pexels-photo-1092730.jpeg?auto=compress&cs=tinysrgb&w=800"
                alt="Fresh fruit bowl"
                className="rounded-2xl shadow-2xl w-full h-96 object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Trial Offer Section */}
      <section className="py-16 bg-orange-500">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="bg-white rounded-2xl p-8 shadow-xl">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Special Trial Offer!
            </h2>
            <p className="text-xl text-gray-600 mb-6">
              Try our signature fruit bowl for just ₹90 - perfect for first-time customers
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <span className="text-4xl font-bold text-orange-500">₹90</span>
              <Link
                to="/order"
                className="px-8 py-3 bg-green-500 text-white font-semibold rounded-lg hover:bg-green-600 transition-colors shadow-lg"
              >
                Order Trial Bowl
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              What Our Customers Say
            </h2>
            <p className="text-xl text-gray-600">
              Join thousands of happy customers who trust Fresh on Time
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6 shadow-sm">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-700 mb-4 leading-relaxed">
                  "{testimonial.text}"
                </p>
                <p className="font-semibold text-gray-900">
                  {testimonial.name}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gray-900 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold mb-4">
            Ready to Start Your Healthy Journey?
          </h2>
          <p className="text-xl text-gray-300 mb-8">
            Browse our menu or place your first order today
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/menu"
              className="px-8 py-3 bg-transparent border-2 border-white text-white font-semibold rounded-lg hover:bg-white hover:text-gray-900 transition-colors"
            >
              Browse Menu
            </Link>
            <Link
              to="/order"
              className="px-8 py-3 bg-orange-500 text-white font-semibold rounded-lg hover:bg-orange-600 transition-colors"
            >
              Order Now
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;