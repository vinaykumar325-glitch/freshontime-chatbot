import React from 'react';
import { Link } from 'react-router-dom';
import { Phone, Instagram } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-900 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Logo & Slogan */}
          <div className="space-y-4">
            <Link to="/" className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center">
                <span className="text-white font-bold text-sm">F</span>
              </div>
              <span className="text-xl font-bold">Fresh on Time</span>
            </Link>
            <p className="text-gray-300 text-sm leading-relaxed">
              Stay Healthy, Stay with Fresh on Time
            </p>
          </div>

          {/* Contact Info */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Contact Info</h3>
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <Phone className="w-4 h-4 text-green-400" />
                <div className="text-sm">
                  <div>7995938999</div>
                  <div>9493532172</div>
                </div>
              </div>
              <div className="flex items-center space-x-3">
                <Instagram className="w-4 h-4 text-green-400" />
                <a 
                  href="https://instagram.com/freshtontime" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-sm hover:text-green-400 transition-colors"
                >
                  @freshtontime
                </a>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Quick Links</h3>
            <nav className="flex flex-col space-y-2">
              <Link to="/menu" className="text-sm text-gray-300 hover:text-green-400 transition-colors">
                Menu
              </Link>
              <Link to="/order" className="text-sm text-gray-300 hover:text-green-400 transition-colors">
                Order Now
              </Link>
              <Link to="/about" className="text-sm text-gray-300 hover:text-green-400 transition-colors">
                About Us
              </Link>
              <Link to="/contact" className="text-sm text-gray-300 hover:text-green-400 transition-colors">
                Contact
              </Link>
            </nav>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-8 pt-8 text-center">
          <p className="text-sm text-gray-400">
            © 2025 Fresh on Time. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;