import React, { createContext, useContext, useReducer, ReactNode } from 'react';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  type: 'bowl' | 'extra';
}

export interface CartState {
  items: CartItem[];
  total: number;
  deliveryTime: string;
  orderType: 'one-time' | 'daily' | 'weekly';
  paymentMethod: 'cod' | 'online';
}

type CartAction =
  | { type: 'ADD_ITEM'; payload: Omit<CartItem, 'quantity'> }
  | { type: 'REMOVE_ITEM'; payload: string }
  | { type: 'UPDATE_QUANTITY'; payload: { id: string; quantity: number } }
  | { type: 'SET_DELIVERY_TIME'; payload: string }
  | { type: 'SET_ORDER_TYPE'; payload: 'one-time' | 'daily' | 'weekly' }
  | { type: 'SET_PAYMENT_METHOD'; payload: 'cod' | 'online' }
  | { type: 'CLEAR_CART' };

const initialState: CartState = {
  items: [],
  total: 0,
  deliveryTime: '7:00 AM – 9:00 AM',
  orderType: 'one-time',
  paymentMethod: 'cod',
};

function cartReducer(state: CartState, action: CartAction): CartState {
  switch (action.type) {
    case 'ADD_ITEM': {
      const existingItem = state.items.find(item => item.id === action.payload.id);
      let newItems;
      
      if (existingItem) {
        newItems = state.items.map(item =>
          item.id === action.payload.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        newItems = [...state.items, { ...action.payload, quantity: 1 }];
      }
      
      const total = calculateTotal(newItems, state.orderType);
      return { ...state, items: newItems, total };
    }
    
    case 'REMOVE_ITEM': {
      const newItems = state.items.filter(item => item.id !== action.payload);
      const total = calculateTotal(newItems, state.orderType);
      return { ...state, items: newItems, total };
    }
    
    case 'UPDATE_QUANTITY': {
      const newItems = state.items.map(item =>
        item.id === action.payload.id
          ? { ...item, quantity: Math.max(0, action.payload.quantity) }
          : item
      ).filter(item => item.quantity > 0);
      
      const total = calculateTotal(newItems, state.orderType);
      return { ...state, items: newItems, total };
    }
    
    case 'SET_DELIVERY_TIME':
      return { ...state, deliveryTime: action.payload };
    
    case 'SET_ORDER_TYPE': {
      const total = calculateTotal(state.items, action.payload);
      return { ...state, orderType: action.payload, total };
    }
    
    case 'SET_PAYMENT_METHOD':
      return { ...state, paymentMethod: action.payload };
    
    case 'CLEAR_CART':
      return initialState;
    
    default:
      return state;
  }
}

function calculateTotal(items: CartItem[], orderType: string): number {
  const subtotal = items.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  let discount = 0;
  
  if (orderType === 'daily') discount = 0.1;
  if (orderType === 'weekly') discount = 0.15;
  
  return Math.round(subtotal * (1 - discount));
}

const CartContext = createContext<{
  state: CartState;
  dispatch: React.Dispatch<CartAction>;
} | undefined>(undefined);

export function CartProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(cartReducer, initialState);
  
  return (
    <CartContext.Provider value={{ state, dispatch }}>
      {children}
    </CartContext.Provider>
  );
}

export function useCart() {
  const context = useContext(CartContext);
  if (context === undefined) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
}